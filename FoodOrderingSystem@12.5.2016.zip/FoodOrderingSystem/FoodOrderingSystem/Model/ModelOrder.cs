﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodOrderingSystem.Model
{
    public class ModelOrder
    {

    }

    public class ModelOrderDetails
    {
        public int OrderId { get; set; }
        public string OrderRagCode { get; set; }
        public int OrderTable { get; set; }
        public DateTime OrderTime { get; set; }
        public decimal OrderFoodPrice { get; set; }
        public decimal OrderSvcTax { get; set; }
        public decimal OrderGtsTax { get; set; }
        public decimal OrderTotalPrice { get; set; }
        public int OrderStatus { get; set; }
        public bool OrderIsSeen { get; set; }

    }

    public class ModelOrderFood
    {
        public int OFId { get; set; }
        public int OrderId { get; set; }
        public int OrderFood { get; set; }
        public int OrderFoodQnty { get; set; }
        public decimal OrderFoodCost { get; set; }
        
    }
}
