﻿using FoodOrderingSystem.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodOrderingSystem.ViewModel
{
    public class OrderViewModel
    {
        SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

        public int AddOrder(ModelOrderDetails ModOrderD)
        {
            builder.DataSource = "INTERSOFT-THINK";
            builder.InitialCatalog = "FoodOrderingDB";
            builder.UserID = "sa";
            builder.Password = "project";
            string connectionString = builder.ConnectionString;
            int returnOrderId = 0;
            try
            {
                SqlConnection sqlcon = new SqlConnection(connectionString);
                string sqlcmd1 = "sp_InsertOrderDetails";
                sqlcon.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandType = CommandType.StoredProcedure;
                cmd1.Parameters.Add("@orderid", SqlDbType.Int, 30);
                cmd1.Parameters.AddWithValue("@OrderRagCode", ModOrderD.OrderRagCode);
                cmd1.Parameters.AddWithValue("@OrderTable", ModOrderD.OrderTable);
                cmd1.Parameters.AddWithValue("@OrderTime", ModOrderD.OrderTime);
                cmd1.Parameters.AddWithValue("@OrderFoodPrice", ModOrderD.OrderFoodPrice);
                cmd1.Parameters.AddWithValue("@OrderSvcTax", ModOrderD.OrderSvcTax);
                cmd1.Parameters.AddWithValue("@OrderGtsTax", ModOrderD.OrderGtsTax);
                cmd1.Parameters.AddWithValue("@OrderTotalPrice", ModOrderD.OrderTotalPrice);
                cmd1.Parameters.AddWithValue("@OrderStatus", ModOrderD.OrderStatus);
                cmd1.Parameters.AddWithValue("@OrderIsSeen", ModOrderD.OrderIsSeen);

                cmd1.Parameters["@orderid"].Direction = ParameterDirection.Output;
                cmd1.CommandText = sqlcmd1;
                cmd1.Connection = sqlcon;
                cmd1.ExecuteNonQuery();
                sqlcon.Close();

                returnOrderId = Convert.ToInt32(cmd1.Parameters["@orderid"].Value);
            }

            catch (Exception ex) { }

            return returnOrderId;
        }


        public int AddFoodOrder(ModelOrderFood ModFood)
        {

            builder.DataSource = "INTERSOFT-THINK";
            builder.InitialCatalog = "FoodOrderingDB";
            builder.UserID = "sa";
            builder.Password = "project";
            string connectionString = builder.ConnectionString;
            int returnOrderId = 0;
            try
            {
                SqlConnection sqlcon = new SqlConnection(connectionString);
                DataTable dtCat = new DataTable();
                string sqlcmd1 = "Insert into tbl_OrderFood (OrderId,OrderFood,OrderFoodQnty,OrderFoodCost) values('" + ModFood.OrderId + "','" + ModFood.OrderFood + "','" + ModFood.OrderFoodQnty + "','" + ModFood.OrderFoodCost + "')";
                sqlcon.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = sqlcmd1;
                cmd1.Connection = sqlcon;
                cmd1.ExecuteNonQuery();
                sqlcon.Close();
                returnOrderId = 1;
            }

            catch (Exception ex) { returnOrderId = 0; }

            return returnOrderId;
        }

        public int RemoveFoodOrder(int Oid)
        {

            builder.DataSource = "INTERSOFT-THINK";
            builder.InitialCatalog = "FoodOrderingDB";
            builder.UserID = "sa";
            builder.Password = "project";
            string connectionString = builder.ConnectionString;
            int returnOrderId = 0;
            try
            {
                SqlConnection sqlcon = new SqlConnection(connectionString);
                DataTable dtCat = new DataTable();
                string sqlcmd1 = "delete from tbl_OrderFood where OrderId = '" + Oid + "'";
                sqlcon.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = sqlcmd1;
                cmd1.Connection = sqlcon;
                cmd1.ExecuteNonQuery();
                sqlcon.Close();
                returnOrderId = 1;
            }

            catch { returnOrderId = 0; }

            return returnOrderId;
        }

        public int RemoveOrder(int Oid)
        {
            builder.DataSource = "INTERSOFT-THINK";
            builder.InitialCatalog = "FoodOrderingDB";
            builder.UserID = "sa";
            builder.Password = "project";
            string connectionString = builder.ConnectionString;
            int returnOrderId = 0;
            try
            {
                SqlConnection sqlcon = new SqlConnection(connectionString);
                DataTable dtCat = new DataTable();
                string sqlcmd1 = "Delete from tbl_OrderDetails where OrderId = '" + Oid + "'";
                sqlcon.Open();
                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = sqlcmd1;
                cmd1.Connection = sqlcon;
                cmd1.ExecuteNonQuery();
                sqlcon.Close();
                returnOrderId = 1;
            }

            catch { returnOrderId = 0; }

            return returnOrderId;
        }

        public List<ModelOrderDetails> GetPendingOrder(int TblId)
        {
            List<ModelOrderDetails> newOrderList = new List<ModelOrderDetails>();

            builder.DataSource = "INTERSOFT-THINK";
            builder.InitialCatalog = "FoodOrderingDB";
            builder.UserID = "sa";
            builder.Password = "project";
            string connectionString = builder.ConnectionString;
            SqlConnection sqlcon = new SqlConnection(connectionString);
            DataTable dtCat = new DataTable();
            string sqlcmd1 = "select * from tbl_OrderDetails where OrderTable='" + TblId + "'";
            sqlcon.Open();
            SqlCommand cmd1 = new SqlCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = sqlcmd1;
            SqlDataAdapter da1 = new SqlDataAdapter(sqlcmd1, sqlcon);
            da1.Fill(dtCat);
            sqlcon.Close();

            foreach (DataRow drs in dtCat.Rows)
            {
                ModelOrderDetails modOreder = new ModelOrderDetails();
                modOreder.OrderId = Convert.ToInt32(drs["OrderId"]);
                modOreder.OrderTime = Convert.ToDateTime(drs["OrderTime"]);
                modOreder.OrderFoodPrice = Convert.ToDecimal(drs["OrderFoodPrice"]);
                modOreder.OrderSvcTax = Convert.ToDecimal(drs["OrderSvcTax"]);
                modOreder.OrderGtsTax = Convert.ToDecimal(drs["OrderGtsTax"]);
                modOreder.OrderTotalPrice = Convert.ToDecimal(drs["OrderTotalPrice"]);
                modOreder.OrderStatus = Convert.ToInt32(drs["OrderStatus"]);
                modOreder.OrderIsSeen = Convert.ToBoolean(drs["OrderIsSeen"]);
                newOrderList.Add(modOreder);
            }
            return newOrderList;

        }
    }
}
