﻿using FoodOrderingSystem.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodOrderingSystem.ViewModel
{
    class RestaurantModelView
    {
        SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

        public List<ModelTableRest> GetTableByMacID(string macId)
        {
            builder.DataSource = "INTERSOFT-THINK";
            builder.InitialCatalog = "FoodOrderingDB";
            builder.UserID = "sa";
            builder.Password = "project";
            string connectionString = builder.ConnectionString;

            List<ModelTableRest> newFoodList = new List<ModelTableRest>();

            SqlConnection sqlcon1 = new SqlConnection(connectionString);
            DataTable dtFood = new DataTable();
            string sqlcmdF = "select * from vw_TableRest where TMachineKey = '" + macId + "'";
            sqlcon1.Open();
            SqlCommand cmd1 = new SqlCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = sqlcmdF;
            SqlDataAdapter da1 = new SqlDataAdapter(sqlcmdF, sqlcon1);
            da1.Fill(dtFood);
            sqlcon1.Close();

            foreach (DataRow drF in dtFood.Rows)
            {
                ModelTableRest ObjFD = new ModelTableRest();
                ObjFD.RId = Convert.ToInt32(drF["RId"]);
                ObjFD.RName = Convert.ToString(drF["RName"]);
                ObjFD.TId = Convert.ToInt32(drF["TId"]);
                ObjFD.RPhone = Convert.ToString(drF["RPhone"]);
                ObjFD.RZip = Convert.ToString(drF["RZip"]);
                ObjFD.RCountry = Convert.ToString(drF["RCountry"]);
                ObjFD.RAddress = Convert.ToString(drF["RAddress"]);
                ObjFD.TIp = Convert.ToString(drF["TIp"]);
                ObjFD.TMachineKey = Convert.ToString(drF["TMachineKey"]);
                ObjFD.TName = Convert.ToString(drF["TName"]);
                ObjFD.RGST = Convert.ToString(drF["RGST"]);
                ObjFD.RServiceTax = Convert.ToString(drF["RServiceTax"]);

                //ObjFD.RServiceTax = Convert.ToString(drF["RServiceTax"]);

                newFoodList.Add(ObjFD);
            }


            return newFoodList;
        }

    }
}
