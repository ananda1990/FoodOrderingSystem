﻿using FoodOrderingSystem.Model;
using FoodOrderingSystem.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Linq;
using System.Management;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FoodOrderingSystem.View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region
        FoodViewModel ObjFood = new FoodViewModel();
        RestaurantModelView ObjRest = new RestaurantModelView();
        OrderViewModel ObjOrder = new OrderViewModel();
        List<ModelSessionFood> FoodOrederList = new List<ModelSessionFood>();
        #endregion

        UniformGrid uniformgridButtons;

        public MainWindow()
        {
            InitializeComponent();
            // winDash.MinWidth = 518;
            txtsearch.Text = "Search your food....";
            Application.Current.Properties["Foods"] = FoodOrederList;
            Application.Current.Properties["SubTotalAmnt"] = "0.00";

            if (CheckConnection("http://example.com/") == true)
            {
                BindData();
            }
            else
            {
                MessageBox.Show("Please check your Internet connection!");
                try
                {
                    Application curApp = Application.Current;
                    curApp.Shutdown();
                }
                catch { }

            }

            // ((INotifyCollectionChanged)dataFood.Items).CollectionChanged +=  mListBox_CollectionChanged;
            //SessionLoad();
        }
        private void mListBox_CollectionChanged(object sender,
    NotifyCollectionChangedEventArgs e)
        {
            //if (e.Action == NotifyCollectionChangedAction.Add)
            //{
            //    // scroll the new item into view  
            //    mListBox.ScrollIntoView(e.NewItems[0]);
            //}

            List<ModelSessionFood> sessionOrderFoodTotal = new List<ModelSessionFood>();
            sessionOrderFoodTotal = (List<ModelSessionFood>)Application.Current.Properties["Foods"];

            try
            {



                foreach (var item in dataFood.Items)
                {
                    // Get the ListBoxItem around the Book
                    ListBoxItem listBoxItem =
                        this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;

                    // Get the ContentPresenter
                    ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                    if (presenter != null)
                    {



                        // Get the Template instance
                        DataTemplate template = presenter.ContentTemplate;

                        // Find the CheckBox within the Template
                        TextBlock checkBox = template.FindName("textfoodid", presenter) as TextBlock;
                        Image imgtick = (Image)template.FindName("imgtick", presenter);

                        int fid = Convert.ToInt32(checkBox.Text);
                        bool hasFood = sessionOrderFoodTotal.Any(cus => cus.FId == fid);
                        if (hasFood == true)
                        {
                            listBoxItem.IsSelected = true;
                            imgtick.Visibility = Visibility.Visible;
                        }
                        else
                        {
                            listBoxItem.IsSelected = false;
                            imgtick.Visibility = Visibility.Hidden;
                        }

                    }
                }

                dataFood.Focus();
            }
            catch { }
        }

        private void SessionLoad()
        {
            List<ModelSessionFood> sessionOrderFoodTotal = new List<ModelSessionFood>();
            sessionOrderFoodTotal = (List<ModelSessionFood>)Application.Current.Properties["Foods"];
            //foreach (var listBoxItem in dataFood.Items)
            //{
            //    ModelFood Fmdl = listBoxItem as ModelFood;
            //    int fid = Fmdl.FId;
            //    bool hasFood = sessionOrderFoodTotal.Any(cus => cus.FId == fid);
            //    //TextBlock textfoodid = (TextBlock)listBoxItem.FindName("textfoodid");

            //    if (hasFood == true)
            //    {
            //        var FoodListitem = listBoxItem as ListBoxItem;
            //        FoodListitem.IsSelected = true;
            //    }
            //    else
            //    {

            //    }

            //}



        }

        private void UniformGrid_Loaded(object sender, RoutedEventArgs e)
        {
            uniformgridButtons = sender as UniformGrid;
        }

        private void BindData()
        {
            //Bind Category first
            List<ModelFoodCategory> ListCat = new List<ModelFoodCategory>();
            ListCat = ObjFood.GetAllCat();
            cmbocategory.ItemsSource = ListCat;
            cmbocategory.DisplayMemberPath = "FCName";
            cmbocategory.SelectedValuePath = "FCId";
            cmbocategory.SelectedIndex = 0;

            //get basic bill details
            string cpuInfo = string.Empty;
            ManagementClass mc = new ManagementClass("win32_processor");
            ManagementObjectCollection moc = mc.GetInstances();

            foreach (ManagementObject mo in moc)
            {
                cpuInfo = mo.Properties["processorID"].Value.ToString();
                break;
            }

            List<ModelTableRest> ListRestTable = new List<ModelTableRest>();
            ListRestTable = ObjRest.GetTableByMacID(cpuInfo);
            string strsvc = string.Empty;
            string strgst = string.Empty;
            foreach (ModelTableRest MTbl in ListRestTable)
            {
                hdntxt.Text = Convert.ToString(MTbl.TId);
                txtRestName.Text = MTbl.RName;
                txtPhn.Text = "Tel: " + MTbl.RPhone;
                txtTbl.Text = MTbl.TName;
                string strRsp = RandomString(4) + DateTime.Now.ToString("yyyyMMddHHmmss");
                txtRecpNo.Text = "Rcpt#: " + strRsp;
                DateTime dt = DateTime.Now;
                string strDate = String.Format("{0:MM/dd/yyyy}", dt) + " " + String.Format("{0:t}", dt);
                txtDate.Text = strDate;
                strsvc = MTbl.RServiceTax;
                strgst = MTbl.RGST;
                txtlblsvc.Text = MTbl.RServiceTax + "% SVC CHG";
                txtlblgst.Text = MTbl.RGST + "% GST";
                txtaddress.Text = MTbl.RAddress;
                txtcountry.Text = MTbl.RCountry + " - " + MTbl.RZip;


            }
            txtsubtamnt.Text = "$ " + Convert.ToString(Application.Current.Properties["SubTotalAmnt"]);
            string strsvcamnt = string.Empty;
            string strgstamnt = string.Empty;
            strsvcamnt = string.Format("{0:0.00}", (Convert.ToDecimal((Convert.ToDouble(Convert.ToDouble(Application.Current.Properties["SubTotalAmnt"]) * Convert.ToDouble(strsvc)) / 100))));
            txtsvc.Text = "$ " + strsvcamnt;
            strgstamnt = string.Format("{0:0.00}", (Convert.ToDecimal((Convert.ToDouble(Convert.ToDouble(Application.Current.Properties["SubTotalAmnt"]) * Convert.ToDouble(strgst)) / 100))));
            txtgst.Text = "$ " + strgstamnt;
            Application.Current.Properties["SVCamnt"] = strsvc;
            Application.Current.Properties["GSTamnt"] = strgst;
            txttotalamnt.Text = "$ " + string.Format("{0:0.00}", (Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(Application.Current.Properties["SubTotalAmnt"]) + Convert.ToDouble(strsvcamnt) + Convert.ToDouble(strgstamnt)))));

            List<ModelOrderDetails> CheckPendingOrder = ObjOrder.GetPendingOrder(Convert.ToInt32(hdntxt.Text));
            if (CheckPendingOrder.Count > 0)
            {
                txtNoOrder.Visibility = Visibility.Visible;
                scrlData.Visibility = Visibility.Collapsed;
            }
            else
            {
                txtNoOrder.Visibility = Visibility.Collapsed;
                scrlData.Visibility = Visibility.Visible;
            }

        }

        private void txtsearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtsearch.Text))
            {
                //set default message in normal chars
                //txtsearch.Text = "Search your food....";
            }
            else
            {
                //do search
            }
        }

        private void txtsearch_GotFocus(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtsearch.Text))
            {
                //set default message in normal chars
                txtsearch.Text = "Search your food....";
            }
            else if (txtsearch.Text == "Search your food....")
            {
                txtsearch.Text = "";
            }
        }

        private void txtsearch_FocusableChanged(object sender, DependencyPropertyChangedEventArgs e)
        {

        }

        private void txtsearch_LostFocus(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtsearch.Text))
            {
                //set default message in normal chars
                txtsearch.Text = "Search your food....";
            }
        }

        private void cmbocategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //dataFood.
            //MessageBox.Show("Value is : "+ cmbocategory.SelectedValue);
            BindFoods(Convert.ToInt32(cmbocategory.SelectedValue));
            dataFood.Focus();
            //PerformClick(btnOrders);
            //btnOrders.Click += Button_Click;

        }

        private void PerformClick(Button btnOrders)
        {
            btnOrders.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OrderList windowTwo = new OrderList();
            //Page1 windowTwo = new Page1();
            //this.NavigationService.Navigate(windowTwo);
            //this will close parent window. windowOne in this case
            this.Close();
            //this will open your child window
            windowTwo.Show();

        }



        private void BindFoods(int catid)
        {
            try
            {

                string strSearchText = txtsearch.Text.TrimStart().TrimEnd();
                if (string.IsNullOrEmpty(strSearchText) || strSearchText == "Search your food....")
                {
                    List<ModelFood> ListFood = new List<ModelFood>();
                    if (catid == 0)
                    {
                        ListFood = ObjFood.GetAllFood();
                        //dataFood.ItemsSource = ListFood;
                        //dataFood.Items.Refresh();


                    }
                    else
                    {
                        ListFood = ObjFood.GetFoodByCat(catid);
                        //dataFood.ItemsSource = ListFood;
                        //dataFood.Items.Refresh();
                    }

                    if (dataFood.Items.Count > 0)
                    {
                        if (catid == 0)
                        {
                            foreach (var item in dataFood.Items)
                            {
                                ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                                ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                                DataTemplate template = presenter.ContentTemplate;
                                listBoxItem.Visibility = Visibility.Visible;
                            }
                        }
                        else
                        {
                            foreach (var item in dataFood.Items)
                            {

                                ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                                ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                                DataTemplate template = presenter.ContentTemplate;
                                // Sta textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                                TextBlock textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                                listBoxItem.Visibility = Visibility.Visible;
                                bool hasFood = ListFood.Any(cus => cus.FId == Convert.ToInt32(textfoodid.Text));
                                if (hasFood == false)
                                {
                                    listBoxItem.Visibility = Visibility.Collapsed;
                                }
                            }
                        }
                        dataFood.Focus();

                    }
                    else
                    {
                        dataFood.ItemsSource = ListFood;
                        dataFood.Focus();
                    }
                }
                else
                {
                    int catId = Convert.ToInt32(cmbocategory.SelectedValue);
                    List<ModelFood> ListFood = new List<ModelFood>();
                    if (catId == 0)
                    {
                        ListFood = ObjFood.GetFoodBySearchKey(strSearchText);
                        //dataFood.ItemsSource = ListFood;
                        //dataFood.Items.Refresh();


                    }
                    else
                    {
                        ListFood = ObjFood.GetFoodBySearchKeyWithCat(strSearchText, catId);
                        //dataFood.ItemsSource = ListFood;
                        //dataFood.Items.Refresh();
                    }
                    if (ListFood.Count > 0)
                    {
                        if (dataFood.Items.Count > 0)
                        {
                            foreach (var item in dataFood.Items)
                            {
                                ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                                ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                                DataTemplate template = presenter.ContentTemplate;
                                // Sta textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                                TextBlock textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                                listBoxItem.Visibility = Visibility.Visible;
                                bool hasFood = ListFood.Any(cus => cus.FId == Convert.ToInt32(textfoodid.Text));
                                if (hasFood == false)
                                {
                                    listBoxItem.Visibility = Visibility.Collapsed;
                                }
                            }
                            dataFood.Focus();
                        }
                        else
                        {
                            dataFood.ItemsSource = ListFood;
                            dataFood.Focus();
                        }
                    }
                    else
                    {
                        foreach (var item in dataFood.Items)
                        {
                            ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                            listBoxItem.Visibility = Visibility.Collapsed;

                        }
                        MessageBox.Show("No Data Found!");

                    }
                }

            }
            catch { }
        }

        private void Window_StateChanged(object sender, EventArgs e)
        {
            try
            {
                if (winDash.WindowState == WindowState.Maximized)
                {
                    // Window is currently maximized.
                    uniformgridButtons.Columns = 5;
                }
                else
                {
                    uniformgridButtons.Columns = 3;
                }
            }
            catch { }

        }

        private void dataFood_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {


                var FoodListitem = ItemsControl.ContainerFromElement(dataFood, e.OriginalSource as DependencyObject) as ListBoxItem;
                ContentPresenter foodContentPresenter = FindVisualChild<ContentPresenter>(FoodListitem);

                DataTemplate foodDataTemplate = foodContentPresenter.ContentTemplate;

                if (FoodListitem != null)
                {
                    // ListBox item clicked - do some cool things here
                    //MessageBox.Show("select");
                    if (FoodListitem.IsSelected == true) //this means already selected
                    {
                        TextBlock textfoodid = (TextBlock)foodDataTemplate.FindName("textfoodid", foodContentPresenter);
                        TextBlock textfoodprice = (TextBlock)foodDataTemplate.FindName("textfoodprice", foodContentPresenter);
                        //textfoodid.Visibility= Visibility.Visible;
                        int FID = Convert.ToInt32(textfoodid.Text);
                        List<ModelSessionFood> sessionOrderFoodRMV = new List<ModelSessionFood>();
                        sessionOrderFoodRMV = (List<ModelSessionFood>)Application.Current.Properties["Foods"];

                        var mdf = sessionOrderFoodRMV.RemoveAll(x => x.FId == FID);
                        //sessionOrderFoodRMV.Remove(mdf);
                        Image imgtick = (Image)foodDataTemplate.FindName("imgtick", foodContentPresenter);
                        imgtick.Visibility = Visibility.Hidden;
                        Application.Current.Properties["Foods"] = sessionOrderFoodRMV;


                        //remove item
                        decimal foodqnty = 0;
                        for (int j = 0; j < grvItemorder.Items.Count; j++)
                        {
                            OrderedFood FDobj = new OrderedFood();
                            FDobj = grvItemorder.Items[j] as OrderedFood;
                            if (FDobj.Fid == FID)
                            {
                                foodqnty = Convert.ToDecimal(FDobj.Qty);
                                grvItemorder.Items.Remove(FDobj);
                            }
                        }

                        //minus price
                        decimal strSubtotal = Convert.ToDecimal(Application.Current.Properties["SubTotalAmnt"]);
                        decimal strSVC = Convert.ToDecimal(Application.Current.Properties["SVCamnt"]);
                        decimal strGST = Convert.ToDecimal(Application.Current.Properties["GSTamnt"]);
                        strSubtotal = strSubtotal - (Convert.ToDecimal(textfoodprice.Text.Replace("$", "")) * foodqnty);
                        Application.Current.Properties["SubTotalAmnt"] = strSubtotal;
                        txtsubtamnt.Text = "$ " + string.Format("{0:0.00}", strSubtotal);
                        string strsvcamnt = string.Empty;
                        string strgstamnt = string.Empty;
                        strsvcamnt = string.Format("{0:0.00}", (Convert.ToDecimal((Convert.ToDouble(Convert.ToDouble(strSubtotal) * Convert.ToDouble(strSVC)) / 100))));
                        txtsvc.Text = "$ " + strsvcamnt;
                        strgstamnt = string.Format("{0:0.00}", (Convert.ToDecimal((Convert.ToDouble(Convert.ToDouble(strSubtotal) * Convert.ToDouble(strGST)) / 100))));
                        txtgst.Text = "$ " + strgstamnt;
                        // Application.Current.Properties["SVCamnt"] = strsvcamnt;
                        //Application.Current.Properties["GSTamnt"] = strgstamnt;
                        txttotalamnt.Text = "$ " + string.Format("{0:0.00}", (Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(strSubtotal) + Convert.ToDouble(strsvcamnt) + Convert.ToDouble(strgstamnt)))));






                    }
                    else
                    {
                        stlBill.Visibility = Visibility.Visible;
                        scrlBill.Visibility = Visibility.Visible;
                        //MessageBox.Show("unselect");
                        //TextBlock textfoodname = (TextBlock)foodDataTemplate.FindName("textfoodname", foodContentPresenter);
                        TextBlock textfoodname = (TextBlock)foodDataTemplate.FindName("textfoodname", foodContentPresenter);
                        TextBlock textfoodprice = (TextBlock)foodDataTemplate.FindName("textfoodprice", foodContentPresenter);
                        TextBlock textfoodid = (TextBlock)foodDataTemplate.FindName("textfoodid", foodContentPresenter);
                        TextBlock textfoodcatgryt = (TextBlock)foodDataTemplate.FindName("textfoodcatgryt", foodContentPresenter);
                        Image imgtick = (Image)foodDataTemplate.FindName("imgtick", foodContentPresenter);
                        imgtick.Visibility = Visibility.Visible;



                        string strFoodName = textfoodname.Text;
                        string strFoodPrice = textfoodprice.Text.Replace("$", "");
                        string strFoodId = textfoodid.Text;
                        string strFoodCatg = textfoodcatgryt.Text;
                        //MessageBox.Show(strFoodName);
                        List<ModelSessionFood> sessionOrderFood = new List<ModelSessionFood>();
                        sessionOrderFood = (List<ModelSessionFood>)Application.Current.Properties["Foods"];
                        ModelSessionFood SFOOD = new ModelSessionFood();
                        SFOOD.FName = strFoodName;
                        SFOOD.FCat = Convert.ToInt32(strFoodCatg);
                        SFOOD.FId = Convert.ToInt32(strFoodId);
                        SFOOD.FPrice = strFoodPrice;
                        sessionOrderFood.Add(SFOOD);

                        Application.Current.Properties["Foods"] = sessionOrderFood;
                        int expou = sessionOrderFood.Count;

                        //add price
                        decimal strSubtotal = Convert.ToDecimal(Application.Current.Properties["SubTotalAmnt"]);
                        decimal strSVC = Convert.ToDecimal(Application.Current.Properties["SVCamnt"]);
                        decimal strGST = Convert.ToDecimal(Application.Current.Properties["GSTamnt"]);
                        strSubtotal = strSubtotal + Convert.ToDecimal(strFoodPrice);
                        Application.Current.Properties["SubTotalAmnt"] = strSubtotal;
                        txtsubtamnt.Text = "$ " + string.Format("{0:0.00}", strSubtotal);
                        string strsvcamnt = string.Empty;
                        string strgstamnt = string.Empty;
                        strsvcamnt = string.Format("{0:0.00}", (Convert.ToDecimal((Convert.ToDouble(Convert.ToDouble(strSubtotal) * Convert.ToDouble(strSVC)) / 100))));
                        txtsvc.Text = "$ " + strsvcamnt;
                        strgstamnt = string.Format("{0:0.00}", (Convert.ToDecimal((Convert.ToDouble(Convert.ToDouble(strSubtotal) * Convert.ToDouble(strGST)) / 100))));
                        txtgst.Text = "$ " + strgstamnt;
                        // Application.Current.Properties["SVCamnt"] = strsvcamnt;
                        //Application.Current.Properties["GSTamnt"] = strgstamnt;
                        txttotalamnt.Text = "$ " + string.Format("{0:0.00}", (Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(Application.Current.Properties["SubTotalAmnt"]) + Convert.ToDouble(strsvcamnt) + Convert.ToDouble(strgstamnt)))));


                        //item add to order list
                        OrderedFood FDobj = new OrderedFood();
                        FDobj.Fid = Convert.ToInt32(strFoodId);
                        FDobj.Item = strFoodName;
                        FDobj.Qty = "1";
                        FDobj.Cost = "$" + strFoodPrice;
                        grvItemorder.Items.Add(FDobj);


                    }


                }
                else
                {
                    // MessageBox.Show("unselect");
                    //txtsearch.Text = "";
                }
            }
            catch { }
        }

        private void dataFood_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                List<ModelSessionFood> sessionOrderFoodTotal = new List<ModelSessionFood>();
                sessionOrderFoodTotal = (List<ModelSessionFood>)Application.Current.Properties["Foods"];

                foreach (var item in this.dataFood.Items)
                {
                    // Get the ListBoxItem around the Book
                    ListBoxItem listBoxItem =
                        this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;

                    // Get the ContentPresenter
                    ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);

                    // Get the Template instance
                    DataTemplate template = presenter.ContentTemplate;

                    // Find the CheckBox within the Template
                    TextBlock checkBox = template.FindName("textfoodid", presenter) as TextBlock;
                    Image imgtick = (Image)template.FindName("imgtick", presenter);

                    int fid = Convert.ToInt32(checkBox.Text);
                    bool hasFood = sessionOrderFoodTotal.Any(cus => cus.FId == fid);
                    if (hasFood == true)
                    {
                        listBoxItem.IsSelected = true;
                        imgtick.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        listBoxItem.IsSelected = false;
                        imgtick.Visibility = Visibility.Hidden;
                    }

                }

                dataFood.Focus();
            }
            catch { }

        }

        public static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj)
       where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }

        public static childItem FindVisualChild<childItem>(DependencyObject obj)
            where childItem : DependencyObject
        {
            foreach (childItem child in FindVisualChildren<childItem>(obj))
            {
                return child;
            }


            return null;
        }

        private void txtsearch_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {

                string strSearchText = txtsearch.Text.TrimStart().TrimEnd();
                if (!string.IsNullOrEmpty(strSearchText))
                {
                    int catId = Convert.ToInt32(cmbocategory.SelectedValue);
                    List<ModelFood> ListFood = new List<ModelFood>();
                    if (catId == 0)
                    {
                        ListFood = ObjFood.GetFoodBySearchKey(strSearchText);
                        //dataFood.ItemsSource = ListFood;
                        //dataFood.Items.Refresh();


                    }
                    else
                    {
                        ListFood = ObjFood.GetFoodBySearchKeyWithCat(strSearchText, catId);
                        //dataFood.ItemsSource = ListFood;
                        //dataFood.Items.Refresh();
                    }
                    if (ListFood.Count > 0)
                    {
                        if (dataFood.Items.Count > 0)
                        {
                            //if (catId == 0)
                            //{
                            //    foreach (var item in dataFood.Items)
                            //    {
                            //        ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                            //        ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                            //        DataTemplate template = presenter.ContentTemplate;
                            //        listBoxItem.Visibility = Visibility.Visible;
                            //    }
                            //}
                            //else
                            //{
                            foreach (var item in dataFood.Items)
                            {

                                ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                                ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                                DataTemplate template = presenter.ContentTemplate;
                                // Sta textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                                TextBlock textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                                listBoxItem.Visibility = Visibility.Visible;
                                bool hasFood = ListFood.Any(cus => cus.FId == Convert.ToInt32(textfoodid.Text));
                                if (hasFood == false)
                                {
                                    listBoxItem.Visibility = Visibility.Collapsed;
                                }
                            }
                            //}
                            //dataFood.Focus();

                        }
                        else
                        {
                            dataFood.ItemsSource = ListFood;
                            //dataFood.Focus();
                        }
                    }
                    else
                    {
                        foreach (var item in dataFood.Items)
                        {
                            ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                            listBoxItem.Visibility = Visibility.Collapsed;

                        }
                        MessageBox.Show("No Data Found!");

                    }

                }

                else
                {
                    BindFoods(Convert.ToInt32(cmbocategory.SelectedValue));
                }

            }
            catch { }
        }

        private void ScrollViewer_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            ScrollViewer scv = (ScrollViewer)sender;
            scv.ScrollToVerticalOffset(scv.VerticalOffset - e.Delta);
            e.Handled = true;
        }

        private void ScrollViewer_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            try
            {

                if (e.NewSize.Width > 865)
                {
                    uniformgridButtons.Columns = 5;
                }
                else if (e.NewSize.Width > 699 && e.NewSize.Width < 865)
                {
                    uniformgridButtons.Columns = 4;
                }
                else
                {
                    uniformgridButtons.Columns = 3;
                }
            }
            catch { }
        }

        private void winDash_Loaded(object sender, RoutedEventArgs e)
        {
            this.MinWidth = 518;
        }

        public string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private void btnsub_Click(object sender, RoutedEventArgs e)
        {
            if (grvItemorder.Items.Count > 0)
            {

                MessageBoxResult result = MessageBox.Show("Would you like to confirm your order ?", "Food Ordering System", MessageBoxButton.YesNo);
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        FinalOrder();
                        break;
                    case MessageBoxResult.No:
                        break;

                }
            }

        }

        private void FinalOrder()
        {
            //submit all
            ModelOrderDetails ObjOrderDetails = new ModelOrderDetails();
            ObjOrderDetails.OrderRagCode = txtRecpNo.Text.Replace("Rcpt#:", "").Trim();
            ObjOrderDetails.OrderTable = Convert.ToInt32(hdntxt.Text);
            ObjOrderDetails.OrderTime = DateTime.Now;
            ObjOrderDetails.OrderFoodPrice = Convert.ToDecimal(txtsubtamnt.Text.Replace("$", ""));
            ObjOrderDetails.OrderSvcTax = Convert.ToDecimal(txtsvc.Text.Replace("$", ""));
            ObjOrderDetails.OrderGtsTax = Convert.ToDecimal(txtgst.Text.Replace("$", ""));
            ObjOrderDetails.OrderTotalPrice = Convert.ToDecimal(txttotalamnt.Text.Replace("$", ""));
            ObjOrderDetails.OrderStatus = 0;   //0 for pending, 1 for delivered and 2 for cancel
            ObjOrderDetails.OrderIsSeen = false;

            int orderid = ObjOrder.AddOrder(ObjOrderDetails);
            int foDONE = 0;
            if (orderid > 0)
            {

                for (int j = 0; j < grvItemorder.Items.Count; j++)
                {
                    OrderedFood customerRow = grvItemorder.Items[j] as OrderedFood;
                    ModelOrderFood objOF = new ModelOrderFood();
                    objOF.OrderId = orderid;
                    objOF.OrderFood = customerRow.Fid;
                    objOF.OrderFoodCost = Convert.ToDecimal(customerRow.Cost.Replace("$", ""));
                    objOF.OrderFoodQnty = Convert.ToInt32(customerRow.Qty);
                    int inserFood = ObjOrder.AddFoodOrder(objOF);
                    if (inserFood == 0)
                    {
                        foDONE = 1;
                    }
                }

                if (foDONE == 1)
                {
                    //delete previous insert
                    int delFood = ObjOrder.RemoveFoodOrder(orderid);
                    int delOrder = ObjOrder.RemoveOrder(orderid);
                    MessageBox.Show("Error Happned! Please try again.");
                }
                else
                {
                    //success
                    CancelAllOrderSelect();
                    scrlData.Visibility = Visibility.Collapsed;
                    txtNoOrder.Visibility = Visibility.Visible;
                    MessageBox.Show("Successful !");
                }

            }
            else
            {
                //delete previous insert
                int delFood = ObjOrder.RemoveFoodOrder(orderid);
                MessageBox.Show("Error Happned! Please try again.");
            }
        }

        private void btncncl_Click(object sender, RoutedEventArgs e)
        {
            scrlBill.Visibility = Visibility.Hidden;
            CancelAllOrderSelect();
        }

        private void CancelAllOrderSelect()
        {
            try
            {
                grvItemorder.Items.Clear();
                Application.Current.Properties["Foods"] = FoodOrederList;
                Application.Current.Properties["SubTotalAmnt"] = "0.00";
                //get basic bill details
                string cpuInfo = string.Empty;
                ManagementClass mc = new ManagementClass("win32_processor");
                ManagementObjectCollection moc = mc.GetInstances();

                foreach (ManagementObject mo in moc)
                {
                    cpuInfo = mo.Properties["processorID"].Value.ToString();
                    break;
                }

                List<ModelTableRest> ListRestTable = new List<ModelTableRest>();
                ListRestTable = ObjRest.GetTableByMacID(cpuInfo);
                string strsvc = string.Empty;
                string strgst = string.Empty;
                foreach (ModelTableRest MTbl in ListRestTable)
                {
                    txtRestName.Text = MTbl.RName;
                    txtPhn.Text = "Tel :" + MTbl.RPhone;
                    txtTbl.Text = MTbl.TName;
                    string strRsp = RandomString(4) + DateTime.Now.ToString("yyyyMMddHHmmss");
                    txtRecpNo.Text = "Rcpt#: " + strRsp;
                    DateTime dt = DateTime.Now;
                    string strDate = String.Format("{0:MM/dd/yyyy}", dt) + " " + String.Format("{0:t}", dt);
                    txtDate.Text = strDate;
                    strsvc = MTbl.RServiceTax;
                    strgst = MTbl.RGST;
                    txtlblsvc.Text = MTbl.RServiceTax + "% SVC CHG";
                    txtlblgst.Text = MTbl.RGST + "% GST";
                    txtaddress.Text = MTbl.RAddress;
                    txtcountry.Text = MTbl.RCountry + " - " + MTbl.RZip;


                }
                txtsubtamnt.Text = "$ " + Convert.ToString(Application.Current.Properties["SubTotalAmnt"]);
                string strsvcamnt = string.Empty;
                string strgstamnt = string.Empty;
                strsvcamnt = string.Format("{0:0.00}", (Convert.ToDecimal((Convert.ToDouble(Convert.ToDouble(Application.Current.Properties["SubTotalAmnt"]) * Convert.ToDouble(strsvc)) / 100) + Convert.ToDouble(Convert.ToDouble(Application.Current.Properties["SubTotalAmnt"])))));
                txtsvc.Text = "$ " + strsvcamnt;
                strgstamnt = string.Format("{0:0.00}", (Convert.ToDecimal((Convert.ToDouble(Convert.ToDouble(Application.Current.Properties["SubTotalAmnt"]) * Convert.ToDouble(strgst)) / 100) + Convert.ToDouble(Convert.ToDouble(Application.Current.Properties["SubTotalAmnt"])))));
                txtgst.Text = "$ " + strgstamnt;

                txttotalamnt.Text = "$ " + string.Format("{0:0.00}", (Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(Application.Current.Properties["SubTotalAmnt"]) + Convert.ToDouble(strsvcamnt) + Convert.ToDouble(strgstamnt)))));
                foreach (var item in dataFood.Items)
                {
                    ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                    ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                    DataTemplate template = presenter.ContentTemplate;
                    Image imgtick = (Image)template.FindName("imgtick", presenter);
                    imgtick.Visibility = Visibility.Collapsed;
                    listBoxItem.IsSelected = false;

                }
            }
            catch { }
        }

        private void ScrollViewer_PreviewMouseWheel_1(object sender, MouseWheelEventArgs e)
        {
            ScrollViewer scv = (ScrollViewer)sender;
            scv.ScrollToVerticalOffset(scv.VerticalOffset - e.Delta);
            e.Handled = true;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                decimal orderqnty = 1;
                OrderedFood customerRow = grvItemorder.SelectedItem as OrderedFood;
                for (int j = 0; j < grvItemorder.Items.Count; j++)
                {
                    OrderedFood FDobj = new OrderedFood();
                    FDobj = grvItemorder.Items[j] as OrderedFood;
                    if (FDobj.Fid == customerRow.Fid)
                    {
                        orderqnty = Convert.ToDecimal(FDobj.Qty);
                        grvItemorder.Items.Remove(FDobj);
                    }
                }

                //unselect item
                foreach (var item in dataFood.Items)
                {
                    ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                    ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                    DataTemplate template = presenter.ContentTemplate;
                    Image imgtick = (Image)template.FindName("imgtick", presenter);
                    TextBlock textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                    if (textfoodid.Text == Convert.ToString(customerRow.Fid))
                    {
                        listBoxItem.IsSelected = false;
                        imgtick.Visibility = Visibility.Collapsed;
                        //price minus
                        TextBlock Ntextfoodname = (TextBlock)template.FindName("textfoodname", presenter);
                        TextBlock Ntextfoodprice = (TextBlock)template.FindName("textfoodprice", presenter);
                        TextBlock Ntextfoodid = (TextBlock)template.FindName("textfoodid", presenter);
                        TextBlock Ntextfoodcatgryt = (TextBlock)template.FindName("textfoodcatgryt", presenter);

                        decimal strSubtotal = Convert.ToDecimal(Application.Current.Properties["SubTotalAmnt"]);
                        decimal strSVC = Convert.ToDecimal(Application.Current.Properties["SVCamnt"]);
                        decimal strGST = Convert.ToDecimal(Application.Current.Properties["GSTamnt"]);
                        strSubtotal = strSubtotal - (Convert.ToDecimal(Ntextfoodprice.Text.Replace("$", "")) * orderqnty);
                        Application.Current.Properties["SubTotalAmnt"] = strSubtotal;
                        txtsubtamnt.Text = "$ " + string.Format("{0:0.00}", strSubtotal);
                        string strsvcamnt = string.Empty;
                        string strgstamnt = string.Empty;
                        strsvcamnt = string.Format("{0:0.00}", (Convert.ToDecimal((Convert.ToDouble(Convert.ToDouble(strSubtotal) * Convert.ToDouble(strSVC)) / 100))));
                        txtsvc.Text = "$ " + strsvcamnt;
                        strgstamnt = string.Format("{0:0.00}", (Convert.ToDecimal((Convert.ToDouble(Convert.ToDouble(strSubtotal) * Convert.ToDouble(strGST)) / 100))));
                        txtgst.Text = "$ " + strgstamnt;
                        // Application.Current.Properties["SVCamnt"] = strsvcamnt;
                        //Application.Current.Properties["GSTamnt"] = strgstamnt;
                        txttotalamnt.Text = "$ " + string.Format("{0:0.00}", (Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(strSubtotal) + Convert.ToDouble(strsvcamnt) + Convert.ToDouble(strgstamnt)))));
                    }

                }



            }
            catch { }


        }

        private void grvItemorder_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            try { }
            catch { }
            ////e.AddedCells[0].Column
            //IList<DataGridCellInfo> cells = e.AddedCells;
            //int strQnty = 0;
            //int fid = 0;
            //string strfoodname = string.Empty;
            //string strprice = string.Empty;
            //foreach (DataGridCellInfo di in cells)
            //{
            //    OrderedFood customerRow = di.Item as OrderedFood;
            //    strQnty = Convert.ToInt32(customerRow.Qty);
            //    strprice = customerRow.Cost;
            //    fid = customerRow.Fid;
            //    strfoodname = customerRow.Item;
            //    //MessageBox.Show(customerRow.Qty);
            //}
            //InputTextBox.Text = strQnty.ToString();
            //txthdn.Text = fid.ToString();
            //txtfoodnamepop.Text = strfoodname;
            //InputBox.Visibility = System.Windows.Visibility.Visible;
            //MessageBox.Show(strQnty.ToString());

        }

        private void YesButton_Click(object sender, RoutedEventArgs e)
        {
            // YesButton Clicked! Let's hide our InputBox and handle the input text.
            if (InputTextBox.Text != "")
            {
                InputBox.Visibility = System.Windows.Visibility.Collapsed;

                int fid = Convert.ToInt32(txthdn.Text);
                string qntity = InputTextBox.Text;
                string costf = txthdnprice.Text;
                decimal totalSubamnt = 0;
                for (int k = 0; k < grvItemorder.Items.Count; k++)
                {
                    OrderedFood FDobj = new OrderedFood();
                    FDobj = grvItemorder.Items[k] as OrderedFood;
                    if (FDobj.Fid == fid)
                    {
                        FDobj.Qty = qntity;
                        FDobj.Cost = "$" + Convert.ToString(Convert.ToDecimal(costf) * Convert.ToDecimal(qntity));
                        grvItemorder.Items.Refresh();
                        totalSubamnt = totalSubamnt + (Convert.ToDecimal(costf) * Convert.ToDecimal(qntity));
                    }
                    else
                    {
                        totalSubamnt = totalSubamnt + Convert.ToDecimal(FDobj.Cost.ToString().Replace("$", ""));
                    }

                    decimal strSVC = Convert.ToDecimal(Application.Current.Properties["SVCamnt"]);
                    decimal strGST = Convert.ToDecimal(Application.Current.Properties["GSTamnt"]);
                    Application.Current.Properties["SubTotalAmnt"] = totalSubamnt;
                    string newSubam = string.Format("{0:0.00}", totalSubamnt);
                    txtsubtamnt.Text = "$" + newSubam;
                    string strsvcamnt = string.Empty;
                    string strgstamnt = string.Empty;
                    strsvcamnt = string.Format("{0:0.00}", (Convert.ToDecimal((Convert.ToDouble(Convert.ToDouble(totalSubamnt) * Convert.ToDouble(strSVC)) / 100))));
                    txtsvc.Text = "$ " + strsvcamnt;
                    strgstamnt = string.Format("{0:0.00}", (Convert.ToDecimal((Convert.ToDouble(Convert.ToDouble(totalSubamnt) * Convert.ToDouble(strGST)) / 100))));
                    txtgst.Text = "$ " + strgstamnt;
                    // Application.Current.Properties["SVCamnt"] = strsvcamnt;
                    //Application.Current.Properties["GSTamnt"] = strgstamnt;
                    txttotalamnt.Text = "$ " + string.Format("{0:0.00}", (Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(totalSubamnt) + Convert.ToDouble(strsvcamnt) + Convert.ToDouble(strgstamnt)))));

                }

                // Clear InputBox.
                InputTextBox.Text = String.Empty;
            }
            else
            {
                MessageBox.Show("Please Enter a numaric value (1-10)!");
            }
        }

        private void NoButton_Click(object sender, RoutedEventArgs e)
        {
            // NoButton Clicked! Let's hide our InputBox.
            InputBox.Visibility = System.Windows.Visibility.Collapsed;

            // Clear InputBox.
            InputTextBox.Text = String.Empty;
        }

        private void InputTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !AreAllValidNumericChars(e.Text);


        }

        private bool AreAllValidNumericChars(string str)
        {
            foreach (char c in str)

            {
                if (c != '.')

                {

                    if (!Char.IsNumber(c))

                    { return false; }
                }
            }
            return true;

        }

        private void InputTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            int val = 0;
            if (InputTextBox.Text != "")
            {
                bool res = Int32.TryParse(InputTextBox.Text, out val);
                if (res == true && val < 11 && val > 0)
                {
                    // add record
                }
                else
                {
                    MessageBox.Show("Please input 1 to 10 only.");
                    InputTextBox.Text = "1";
                    return;
                }
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OrderedFood customerRow = grvItemorder.SelectedItem as OrderedFood;
                InputTextBox.Text = customerRow.Qty.ToString();
                txthdn.Text = customerRow.Fid.ToString();
                txthdnprice.Text = Convert.ToString(Convert.ToDecimal(customerRow.Cost.ToString().Replace("$", "")) / Convert.ToDecimal(customerRow.Qty));
                txtfoodnamepop.Text = customerRow.Item;
                InputBox.Visibility = System.Windows.Visibility.Visible;

            }
            catch { }
        }

        private bool CheckConnection(String URL)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.Timeout = 5000;
                request.Credentials = CredentialCache.DefaultNetworkCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (response.StatusCode == HttpStatusCode.OK) return true;
                else return false;
            }
            catch
            {
                return false;
            }
        }
    }
    public class OrderedFood
    {
        public int Fid { get; set; }
        public string Item { get; set; }
        public string Qty { get; set; }
        public string Cost { get; set; }
    }
}
