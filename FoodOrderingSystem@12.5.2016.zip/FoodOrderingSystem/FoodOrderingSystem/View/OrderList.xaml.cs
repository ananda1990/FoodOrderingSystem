﻿using FoodOrderingSystem.Model;
using FoodOrderingSystem.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FoodOrderingSystem.View
{
    /// <summary>
    /// Interaction logic for OrderList.xaml
    /// </summary>
    public partial class OrderList : Window
    {
        #region
        FoodViewModel ObjFood = new FoodViewModel();
        RestaurantModelView ObjRest = new RestaurantModelView();
        OrderViewModel ObjOrder = new OrderViewModel();
        List<ModelSessionFood> FoodOrederList = new List<ModelSessionFood>();
        #endregion

        public OrderList()
        {
            InitializeComponent();
           
        }

        private void LoadPendingData()
        {
            //get basic bill details
            string cpuInfo = string.Empty;
            ManagementClass mc = new ManagementClass("win32_processor");
            ManagementObjectCollection moc = mc.GetInstances();

            foreach (ManagementObject mo in moc)
            {
                cpuInfo = mo.Properties["processorID"].Value.ToString();
                break;
            }

            List<ModelTableRest> ListRestTable = new List<ModelTableRest>();
            ListRestTable = ObjRest.GetTableByMacID(cpuInfo);
            int tblId = 0;
            foreach (ModelTableRest MTbl in ListRestTable)
            {
                tblId = MTbl.TId;
            }
            List<ModelOrderDetails> CheckPendingOrder = ObjOrder.GetPendingOrder(Convert.ToInt32(tblId));
            if (CheckPendingOrder.Count > 0)
            {
            }
            else
            {
                MessageBox.Show("No Waiting Order!");
            }
        }

        private void btnback_Click(object sender, RoutedEventArgs e)
        {
            MainWindow windowTwo = new MainWindow();
            //this will close parent window. windowOne in this case
            this.Close();
            //this will open your child window
            windowTwo.Show();
            
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadPendingData();
        }
    }
}
