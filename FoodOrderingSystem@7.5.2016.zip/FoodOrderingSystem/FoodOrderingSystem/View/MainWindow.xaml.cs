﻿using FoodOrderingSystem.Model;
using FoodOrderingSystem.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FoodOrderingSystem.View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region
        FoodViewModel ObjFood = new FoodViewModel();

        List<ModelSessionFood> FoodOrederList = new List<ModelSessionFood>();
        #endregion

        UniformGrid uniformgridButtons;

        public MainWindow()
        {
            InitializeComponent();
            txtsearch.Text = "Search your food....";
            Application.Current.Properties["Foods"] = FoodOrederList;
            BindData();
        }

        private void UniformGrid_Loaded(object sender, RoutedEventArgs e)
        {
            uniformgridButtons = sender as UniformGrid;
        }

        private void BindData()
        {
            //Bind Category first
            List<ModelFoodCategory> ListCat = new List<ModelFoodCategory>();
            ListCat = ObjFood.GetAllCat();
            cmbocategory.ItemsSource = ListCat;
            cmbocategory.DisplayMemberPath = "FCName";
            cmbocategory.SelectedValuePath = "FCId";
            cmbocategory.SelectedIndex = 0;

        }

        private void txtsearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtsearch.Text))
            {
                //set default message in normal chars
                //txtsearch.Text = "Search your food....";
            }
            else
            {
                //do search
            }
        }

        private void txtsearch_GotFocus(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtsearch.Text))
            {
                //set default message in normal chars
                txtsearch.Text = "Search your food....";
            }
            else if (txtsearch.Text == "Search your food....")
            {
                txtsearch.Text = "";
            }
        }

        private void txtsearch_FocusableChanged(object sender, DependencyPropertyChangedEventArgs e)
        {

        }

        private void txtsearch_LostFocus(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtsearch.Text))
            {
                //set default message in normal chars
                txtsearch.Text = "Search your food....";
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void cmbocategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //MessageBox.Show("Value is : "+ cmbocategory.SelectedValue);
            BindFoods(Convert.ToInt32(cmbocategory.SelectedValue));
        }

        private void BindFoods(int catid)
        {
            List<ModelFood> ListFood = new List<ModelFood>();
            if (catid == 0)
            {
                ListFood = ObjFood.GetAllFood();
                dataFood.ItemsSource = ListFood;
            }
            else
            {
                ListFood = ObjFood.GetFoodByCat(catid);
                dataFood.ItemsSource = ListFood;
            }
        }

        private void Window_StateChanged(object sender, EventArgs e)
        {
            if (winDash.WindowState == WindowState.Maximized)
            {
                // Window is currently maximized.
                uniformgridButtons.Columns = 4;
            }
            else
            {
                uniformgridButtons.Columns = 3;
            }
        }

        private void dataFood_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            var FoodListitem = ItemsControl.ContainerFromElement(dataFood, e.OriginalSource as DependencyObject) as ListBoxItem;
            ContentPresenter foodContentPresenter = FindVisualChild<ContentPresenter>(FoodListitem);

            DataTemplate foodDataTemplate = foodContentPresenter.ContentTemplate;
            
            if (FoodListitem != null)
            {
                // ListBox item clicked - do some cool things here
                //MessageBox.Show("select");
                if (FoodListitem.IsSelected == true ) //this means already selected
                {
                    TextBlock textfoodid = (TextBlock)foodDataTemplate.FindName("textfoodid", foodContentPresenter);
                    int FID = Convert.ToInt32(textfoodid.Text);
                    List<ModelSessionFood> sessionOrderFoodRMV = new List<ModelSessionFood>();
                    sessionOrderFoodRMV = (List<ModelSessionFood>)Application.Current.Properties["Foods"];

                    var mdf = sessionOrderFoodRMV.RemoveAll(x => x.FId == FID);
                    //sessionOrderFoodRMV.Remove(mdf);

                    Application.Current.Properties["Foods"] = sessionOrderFoodRMV;

                }
                else
                {
                     //MessageBox.Show("unselect");
                    //TextBlock textfoodname = (TextBlock)foodDataTemplate.FindName("textfoodname", foodContentPresenter);
                    TextBlock textfoodname = (TextBlock)foodDataTemplate.FindName("textfoodname", foodContentPresenter);
                    TextBlock textfoodprice = (TextBlock)foodDataTemplate.FindName("textfoodprice", foodContentPresenter);
                    TextBlock textfoodid = (TextBlock)foodDataTemplate.FindName("textfoodid", foodContentPresenter);
                    TextBlock textfoodcatgryt = (TextBlock)foodDataTemplate.FindName("textfoodcatgryt", foodContentPresenter);
                    


                    string strFoodName = textfoodname.Text;
                    string strFoodPrice = textfoodprice.Text;
                    string strFoodId = textfoodid.Text;
                    string strFoodCatg = textfoodcatgryt.Text;
                    //MessageBox.Show(strFoodName);
                    List<ModelSessionFood> sessionOrderFood = new List<ModelSessionFood>();
                    sessionOrderFood = (List<ModelSessionFood>)Application.Current.Properties["Foods"];
                    ModelSessionFood SFOOD = new ModelSessionFood();
                    SFOOD.FName = strFoodName;
                    SFOOD.FCat = Convert.ToInt32(strFoodCatg);
                    SFOOD.FId = Convert.ToInt32(strFoodId);
                    SFOOD.FPrice = strFoodName;
                    sessionOrderFood.Add(SFOOD);
                    
                    Application.Current.Properties["Foods"] = sessionOrderFood;
                    int expou = sessionOrderFood.Count;



                }

                
            }
            else
            {
                // MessageBox.Show("unselect");
                //txtsearch.Text = "";
            }
        }

        private void dataFood_Loaded(object sender, RoutedEventArgs e)
        {
            List<ModelSessionFood> sessionOrderFoodTotal = new List<ModelSessionFood>();
            sessionOrderFoodTotal = (List<ModelSessionFood>)Application.Current.Properties["Foods"];
            foreach (var listBoxItem in dataFood.Items)
            {
                ModelFood Fmdl = listBoxItem as ModelFood;
                int fid = Fmdl.FId;
                bool hasFood = sessionOrderFoodTotal.Any(cus => cus.FId == fid);
                //TextBlock textfoodid = (TextBlock)listBoxItem.FindName("textfoodid");

               if (hasFood == true)
                {
                    
                }

            }
        }



        public static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj)
       where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }

        public static childItem FindVisualChild<childItem>(DependencyObject obj)
            where childItem : DependencyObject
        {
            foreach (childItem child in FindVisualChildren<childItem>(obj))
            {
                return child;
            }

            return null;
        }

        
    }
}
