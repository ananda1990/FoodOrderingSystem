﻿using FoodOrderingSystem.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Configuration;
using System.Data.SqlServerCe;

namespace FoodOrderingSystem.ViewModel
{
    public class FoodViewModel
    {
        //string connectionString = @"Data Source=INTERSOFT-THINK;Initial Catalog=FoodOrderingDB;Integrated Security=False;Userid=sa;Password=project";
        SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
        
        public List<ModelFoodCategory> GetAllCat()
        {
            builder.DataSource = "INTERSOFT-THINK";
            builder.InitialCatalog = "FoodOrderingDB";
            builder.UserID = "sa";
            builder.Password = "project";
            string connectionString = builder.ConnectionString;

            List<ModelFoodCategory> newCatList = new List<ModelFoodCategory>();

            SqlConnection sqlcon = new SqlConnection(connectionString);
            DataTable dtCat = new DataTable();
            string sqlcmd1 = "select * from tbl_FoodCategory";
            sqlcon.Open();
            SqlCommand cmd1 = new SqlCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = sqlcmd1;
            SqlDataAdapter da1 = new SqlDataAdapter(sqlcmd1, sqlcon);
            da1.Fill(dtCat);
            sqlcon.Close();

            ModelFoodCategory ObjFC1 = new ModelFoodCategory();
            ObjFC1.FCId = 0;
            ObjFC1.FCName = "All";
            newCatList.Add(ObjFC1);
            foreach (DataRow drs in dtCat.Rows)
            {
                ModelFoodCategory ObjFC = new ModelFoodCategory();
                ObjFC.FCId = Convert.ToInt32(drs["FCId"]);
                ObjFC.FCName = Convert.ToString(drs["FCName"]);
                newCatList.Add(ObjFC);
            }
            

            return newCatList;
        }

        public List<ModelFood> GetAllFood()
        {
            builder.DataSource = "INTERSOFT-THINK";
            builder.InitialCatalog = "FoodOrderingDB";
            builder.UserID = "sa";
            builder.Password = "project";
            string connectionString = builder.ConnectionString;

            List<ModelFood> newCatList = new List<ModelFood>();

            SqlConnection sqlcon = new SqlConnection(connectionString);
            DataTable dtCat = new DataTable();
            string sqlcmd1 = "select * from tbl_Food";
            sqlcon.Open();
            SqlCommand cmd1 = new SqlCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = sqlcmd1;
            SqlDataAdapter da1 = new SqlDataAdapter(sqlcmd1, sqlcon);
            da1.Fill(dtCat);
            sqlcon.Close();
            
            foreach (DataRow drs in dtCat.Rows)
            {
                ModelFood ObjFC = new ModelFood();
                ObjFC.FId = Convert.ToInt32(drs["FId"]);
                ObjFC.FName = Convert.ToString(drs["FName"]);
                ObjFC.FImage = "http://192.168.1.149:8043/FoodOrder/Images/" + Convert.ToString(drs["FImage"]);
                ObjFC.FPrice = "$"+Convert.ToString(drs["FPrice"]);
                ObjFC.FCat = Convert.ToInt32(drs["FCat"]);
                //ObjFC.FCName = Convert.ToString(drs["FCName"]);
                newCatList.Add(ObjFC);
            }
            

            return newCatList;
        }

        public List<ModelFood> GetFoodByCat(int catId)
        {
            builder.DataSource = "INTERSOFT-THINK";
            builder.InitialCatalog = "FoodOrderingDB";
            builder.UserID = "sa";
            builder.Password = "project";
            string connectionString = builder.ConnectionString;

            List<ModelFood> newFoodList = new List<ModelFood>();

            SqlConnection sqlcon1 = new SqlConnection(connectionString);
            DataTable dtFood = new DataTable();
            string sqlcmdF = "select * from tbl_Food where FCat='" + catId + "'";
            sqlcon1.Open();
            SqlCommand cmd1 = new SqlCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = sqlcmdF;
            SqlDataAdapter da1 = new SqlDataAdapter(sqlcmdF, sqlcon1);
            da1.Fill(dtFood);
            sqlcon1.Close();
           
            foreach (DataRow drF in dtFood.Rows)
            {
                ModelFood ObjFD = new ModelFood();
                ObjFD.FId = Convert.ToInt32(drF["FId"]);
                ObjFD.FName = Convert.ToString(drF["FName"]);
                ObjFD.FImage = "http://192.168.1.149:8043/FoodOrder/Images/" + Convert.ToString(drF["FImage"]);
                ObjFD.FPrice = "$" + Convert.ToString(drF["FPrice"]);
                ObjFD.FCat = Convert.ToInt32(drF["FCat"]);
                //ObjFC.FCName = Convert.ToString(drs["FCName"]);
                newFoodList.Add(ObjFD);
            }
            

            return newFoodList;
        }

    }
}
