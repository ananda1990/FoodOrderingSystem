﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodOrderingSystem.Model
{
    public class ModelFood
    {
        public int FId { get; set; }
        public string FName { get; set; }
        public string FPrice { get; set; }
        public int FCat { get; set; }
        public string FImage { get; set; }
    }

    public class ModelFoodCategory
    {
        public int FCId { get; set; }
        public string FCName { get; set; }
    }

    public class ModelSessionFood
    {
        public int FId { get; set; }
        public string FName { get; set; }
        public int FCat { get; set; }
        public string FPrice { get; set; }

    }
}
