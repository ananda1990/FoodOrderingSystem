﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodOrderingSystem.Model
{
    public class ModelRestaurant
    {
        public int RId { get; set; }
        public string RName { get; set; }
        public string RPhone { get; set; }
        public string RCountry { get; set; }
        public string RZip { get; set; }
        public string RAddress { get; set; }
        public string RIP { get; set; }
        public string RGST { get; set; }
        public string RServiceTax { get; set; }
    }
    public class ModelTable
    {
        public int TId { get; set; }
        public int TResId { get; set; }
        public string TName { get; set; }
        public string TIp { get; set; }
        public string TMachineKey { get; set; }

    }
    public class ModelTableRest
    {
        public int RId { get; set; }
        public string RName { get; set; }
        public string RPhone { get; set; }
        public string RCountry { get; set; }
        public string RZip { get; set; }
        public string RAddress { get; set; }
        public string RIP { get; set; }
        public int TId { get; set; }
        public string TName { get; set; }
        public string TIp { get; set; }
        public string TMachineKey { get; set; }
        public string RGST { get; set; }
        public string RServiceTax { get; set; }
    }
}
