﻿using FoodOrderingSystem.Model;
using FoodOrderingSystem.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FoodOrderingSystem.View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region
        FoodViewModel ObjFood = new FoodViewModel();

        List<ModelSessionFood> FoodOrederList = new List<ModelSessionFood>();
        #endregion

        UniformGrid uniformgridButtons;

        public MainWindow()
        {
            InitializeComponent();
           // winDash.MinWidth = 518;
            txtsearch.Text = "Search your food....";
            Application.Current.Properties["Foods"] = FoodOrederList;
            BindData();
            // ((INotifyCollectionChanged)dataFood.Items).CollectionChanged +=  mListBox_CollectionChanged;
            //SessionLoad();
        }
        private void mListBox_CollectionChanged(object sender,
    NotifyCollectionChangedEventArgs e)
        {
            //if (e.Action == NotifyCollectionChangedAction.Add)
            //{
            //    // scroll the new item into view  
            //    mListBox.ScrollIntoView(e.NewItems[0]);
            //}

            List<ModelSessionFood> sessionOrderFoodTotal = new List<ModelSessionFood>();
            sessionOrderFoodTotal = (List<ModelSessionFood>)Application.Current.Properties["Foods"];

            try
            {



                foreach (var item in dataFood.Items)
                {
                    // Get the ListBoxItem around the Book
                    ListBoxItem listBoxItem =
                        this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;

                    // Get the ContentPresenter
                    ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                    if (presenter != null)
                    {



                        // Get the Template instance
                        DataTemplate template = presenter.ContentTemplate;

                        // Find the CheckBox within the Template
                        TextBlock checkBox = template.FindName("textfoodid", presenter) as TextBlock;
                        Image imgtick = (Image)template.FindName("imgtick", presenter);

                        int fid = Convert.ToInt32(checkBox.Text);
                        bool hasFood = sessionOrderFoodTotal.Any(cus => cus.FId == fid);
                        if (hasFood == true)
                        {
                            listBoxItem.IsSelected = true;
                            imgtick.Visibility = Visibility.Visible;
                        }
                        else
                        {
                            listBoxItem.IsSelected = false;
                            imgtick.Visibility = Visibility.Hidden;
                        }

                    }
                }

                dataFood.Focus();
            }
            catch { }
        }

        private void SessionLoad()
        {
            List<ModelSessionFood> sessionOrderFoodTotal = new List<ModelSessionFood>();
            sessionOrderFoodTotal = (List<ModelSessionFood>)Application.Current.Properties["Foods"];
            //foreach (var listBoxItem in dataFood.Items)
            //{
            //    ModelFood Fmdl = listBoxItem as ModelFood;
            //    int fid = Fmdl.FId;
            //    bool hasFood = sessionOrderFoodTotal.Any(cus => cus.FId == fid);
            //    //TextBlock textfoodid = (TextBlock)listBoxItem.FindName("textfoodid");

            //    if (hasFood == true)
            //    {
            //        var FoodListitem = listBoxItem as ListBoxItem;
            //        FoodListitem.IsSelected = true;
            //    }
            //    else
            //    {

            //    }

            //}



        }

        private void UniformGrid_Loaded(object sender, RoutedEventArgs e)
        {
            uniformgridButtons = sender as UniformGrid;
        }

        private void BindData()
        {
            //Bind Category first
            List<ModelFoodCategory> ListCat = new List<ModelFoodCategory>();
            ListCat = ObjFood.GetAllCat();
            cmbocategory.ItemsSource = ListCat;
            cmbocategory.DisplayMemberPath = "FCName";
            cmbocategory.SelectedValuePath = "FCId";
            cmbocategory.SelectedIndex = 0;

        }

        private void txtsearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtsearch.Text))
            {
                //set default message in normal chars
                //txtsearch.Text = "Search your food....";
            }
            else
            {
                //do search
            }
        }

        private void txtsearch_GotFocus(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtsearch.Text))
            {
                //set default message in normal chars
                txtsearch.Text = "Search your food....";
            }
            else if (txtsearch.Text == "Search your food....")
            {
                txtsearch.Text = "";
            }
        }

        private void txtsearch_FocusableChanged(object sender, DependencyPropertyChangedEventArgs e)
        {

        }

        private void txtsearch_LostFocus(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtsearch.Text))
            {
                //set default message in normal chars
                txtsearch.Text = "Search your food....";
            }
        }

        private void cmbocategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //dataFood.
            //MessageBox.Show("Value is : "+ cmbocategory.SelectedValue);
            BindFoods(Convert.ToInt32(cmbocategory.SelectedValue));
            dataFood.Focus();
            //PerformClick(btnOrders);
            //btnOrders.Click += Button_Click;

        }

        private void PerformClick(Button btnOrders)
        {
            btnOrders.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //BindFoods(Convert.ToInt32(cmbocategory.SelectedValue));
            List<ModelSessionFood> sessionOrderFoodTotal = new List<ModelSessionFood>();
            sessionOrderFoodTotal = (List<ModelSessionFood>)Application.Current.Properties["Foods"];

            try
            {



                foreach (var item in dataFood.Items)
                {
                    // Get the ListBoxItem around the Book
                    ListBoxItem listBoxItem =
                        this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;

                    // Get the ContentPresenter
                    ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                    if (presenter != null)
                    {



                        // Get the Template instance
                        DataTemplate template = presenter.ContentTemplate;

                        // Find the CheckBox within the Template
                        TextBlock checkBox = template.FindName("textfoodid", presenter) as TextBlock;
                        Image imgtick = (Image)template.FindName("imgtick", presenter);

                        int fid = Convert.ToInt32(checkBox.Text);
                        bool hasFood = sessionOrderFoodTotal.Any(cus => cus.FId == fid);
                        if (hasFood == true)
                        {
                            listBoxItem.IsSelected = true;
                            imgtick.Visibility = Visibility.Visible;
                        }
                        else
                        {
                            listBoxItem.IsSelected = false;
                            imgtick.Visibility = Visibility.Hidden;
                        }

                    }
                }

                dataFood.Focus();
            }
            catch { }
        }



        private void BindFoods(int catid)
        {
            string strSearchText = txtsearch.Text.TrimStart().TrimEnd();
            if (string.IsNullOrEmpty(strSearchText) || strSearchText == "Search your food....")
            {
                List<ModelFood> ListFood = new List<ModelFood>();
                if (catid == 0)
                {
                    ListFood = ObjFood.GetAllFood();
                    //dataFood.ItemsSource = ListFood;
                    //dataFood.Items.Refresh();


                }
                else
                {
                    ListFood = ObjFood.GetFoodByCat(catid);
                    //dataFood.ItemsSource = ListFood;
                    //dataFood.Items.Refresh();
                }

                if (dataFood.Items.Count > 0)
                {
                    if (catid == 0)
                    {
                        foreach (var item in dataFood.Items)
                        {
                            ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                            ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                            DataTemplate template = presenter.ContentTemplate;
                            listBoxItem.Visibility = Visibility.Visible;
                        }
                    }
                    else
                    {
                        foreach (var item in dataFood.Items)
                        {

                            ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                            ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                            DataTemplate template = presenter.ContentTemplate;
                            // Sta textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                            TextBlock textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                            listBoxItem.Visibility = Visibility.Visible;
                            bool hasFood = ListFood.Any(cus => cus.FId == Convert.ToInt32(textfoodid.Text));
                            if (hasFood == false)
                            {
                                listBoxItem.Visibility = Visibility.Collapsed;
                            }
                        }
                    }
                    dataFood.Focus();

                }
                else
                {
                    dataFood.ItemsSource = ListFood;
                    dataFood.Focus();
                }
            }
            else
            {
                int catId = Convert.ToInt32(cmbocategory.SelectedValue);
                List<ModelFood> ListFood = new List<ModelFood>();
                if (catId == 0)
                {
                    ListFood = ObjFood.GetFoodBySearchKey(strSearchText);
                    //dataFood.ItemsSource = ListFood;
                    //dataFood.Items.Refresh();


                }
                else
                {
                    ListFood = ObjFood.GetFoodBySearchKeyWithCat(strSearchText, catId);
                    //dataFood.ItemsSource = ListFood;
                    //dataFood.Items.Refresh();
                }
                if (ListFood.Count > 0)
                {
                    if (dataFood.Items.Count > 0)
                    {
                        foreach (var item in dataFood.Items)
                        {
                            ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                            ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                            DataTemplate template = presenter.ContentTemplate;
                            // Sta textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                            TextBlock textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                            listBoxItem.Visibility = Visibility.Visible;
                            bool hasFood = ListFood.Any(cus => cus.FId == Convert.ToInt32(textfoodid.Text));
                            if (hasFood == false)
                            {
                                listBoxItem.Visibility = Visibility.Collapsed;
                            }
                        }
                        dataFood.Focus();
                    }
                    else
                    {
                        dataFood.ItemsSource = ListFood;
                        dataFood.Focus();
                    }
                }
                else
                {
                    foreach (var item in dataFood.Items)
                    {
                        ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                        listBoxItem.Visibility = Visibility.Collapsed;

                    }
                    MessageBox.Show("No Data Found!");

                }
            }

        }

        private void Window_StateChanged(object sender, EventArgs e)
        {
            if (winDash.WindowState == WindowState.Maximized)
            {
                // Window is currently maximized.
                uniformgridButtons.Columns = 5;
            }
            else
            {
                uniformgridButtons.Columns = 3;
            }
        }

        private void dataFood_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {


                var FoodListitem = ItemsControl.ContainerFromElement(dataFood, e.OriginalSource as DependencyObject) as ListBoxItem;
                ContentPresenter foodContentPresenter = FindVisualChild<ContentPresenter>(FoodListitem);

                DataTemplate foodDataTemplate = foodContentPresenter.ContentTemplate;

                if (FoodListitem != null)
                {
                    // ListBox item clicked - do some cool things here
                    //MessageBox.Show("select");
                    if (FoodListitem.IsSelected == true) //this means already selected
                    {
                        TextBlock textfoodid = (TextBlock)foodDataTemplate.FindName("textfoodid", foodContentPresenter);
                        //textfoodid.Visibility= Visibility.Visible;
                        int FID = Convert.ToInt32(textfoodid.Text);
                        List<ModelSessionFood> sessionOrderFoodRMV = new List<ModelSessionFood>();
                        sessionOrderFoodRMV = (List<ModelSessionFood>)Application.Current.Properties["Foods"];

                        var mdf = sessionOrderFoodRMV.RemoveAll(x => x.FId == FID);
                        //sessionOrderFoodRMV.Remove(mdf);
                        Image imgtick = (Image)foodDataTemplate.FindName("imgtick", foodContentPresenter);
                        imgtick.Visibility = Visibility.Hidden;
                        Application.Current.Properties["Foods"] = sessionOrderFoodRMV;

                    }
                    else
                    {
                        //MessageBox.Show("unselect");
                        //TextBlock textfoodname = (TextBlock)foodDataTemplate.FindName("textfoodname", foodContentPresenter);
                        TextBlock textfoodname = (TextBlock)foodDataTemplate.FindName("textfoodname", foodContentPresenter);
                        TextBlock textfoodprice = (TextBlock)foodDataTemplate.FindName("textfoodprice", foodContentPresenter);
                        TextBlock textfoodid = (TextBlock)foodDataTemplate.FindName("textfoodid", foodContentPresenter);
                        TextBlock textfoodcatgryt = (TextBlock)foodDataTemplate.FindName("textfoodcatgryt", foodContentPresenter);
                        Image imgtick = (Image)foodDataTemplate.FindName("imgtick", foodContentPresenter);
                        imgtick.Visibility = Visibility.Visible;



                        string strFoodName = textfoodname.Text;
                        string strFoodPrice = textfoodprice.Text;
                        string strFoodId = textfoodid.Text;
                        string strFoodCatg = textfoodcatgryt.Text;
                        //MessageBox.Show(strFoodName);
                        List<ModelSessionFood> sessionOrderFood = new List<ModelSessionFood>();
                        sessionOrderFood = (List<ModelSessionFood>)Application.Current.Properties["Foods"];
                        ModelSessionFood SFOOD = new ModelSessionFood();
                        SFOOD.FName = strFoodName;
                        SFOOD.FCat = Convert.ToInt32(strFoodCatg);
                        SFOOD.FId = Convert.ToInt32(strFoodId);
                        SFOOD.FPrice = strFoodName;
                        sessionOrderFood.Add(SFOOD);

                        Application.Current.Properties["Foods"] = sessionOrderFood;
                        int expou = sessionOrderFood.Count;



                    }


                }
                else
                {
                    // MessageBox.Show("unselect");
                    //txtsearch.Text = "";
                }
            }
            catch { }
        }

        private void dataFood_Loaded(object sender, RoutedEventArgs e)

        {
            List<ModelSessionFood> sessionOrderFoodTotal = new List<ModelSessionFood>();
            sessionOrderFoodTotal = (List<ModelSessionFood>)Application.Current.Properties["Foods"];

            foreach (var item in this.dataFood.Items)
            {
                // Get the ListBoxItem around the Book
                ListBoxItem listBoxItem =
                    this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;

                // Get the ContentPresenter
                ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);

                // Get the Template instance
                DataTemplate template = presenter.ContentTemplate;

                // Find the CheckBox within the Template
                TextBlock checkBox = template.FindName("textfoodid", presenter) as TextBlock;
                Image imgtick = (Image)template.FindName("imgtick", presenter);

                int fid = Convert.ToInt32(checkBox.Text);
                bool hasFood = sessionOrderFoodTotal.Any(cus => cus.FId == fid);
                if (hasFood == true)
                {
                    listBoxItem.IsSelected = true;
                    imgtick.Visibility = Visibility.Visible;
                }
                else
                {
                    listBoxItem.IsSelected = false;
                    imgtick.Visibility = Visibility.Hidden;
                }

            }

            dataFood.Focus();

        }



        public static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj)
       where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }

        public static childItem FindVisualChild<childItem>(DependencyObject obj)
            where childItem : DependencyObject
        {
            foreach (childItem child in FindVisualChildren<childItem>(obj))
            {
                return child;
            }

            return null;
        }

        private void txtsearch_KeyUp(object sender, KeyEventArgs e)
        {
            string strSearchText = txtsearch.Text.TrimStart().TrimEnd();
            if (!string.IsNullOrEmpty(strSearchText))
            {
                int catId = Convert.ToInt32(cmbocategory.SelectedValue);
                List<ModelFood> ListFood = new List<ModelFood>();
                if (catId == 0)
                {
                    ListFood = ObjFood.GetFoodBySearchKey(strSearchText);
                    //dataFood.ItemsSource = ListFood;
                    //dataFood.Items.Refresh();


                }
                else
                {
                    ListFood = ObjFood.GetFoodBySearchKeyWithCat(strSearchText, catId);
                    //dataFood.ItemsSource = ListFood;
                    //dataFood.Items.Refresh();
                }
                if (ListFood.Count > 0)
                {
                    if (dataFood.Items.Count > 0)
                    {
                        //if (catId == 0)
                        //{
                        //    foreach (var item in dataFood.Items)
                        //    {
                        //        ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                        //        ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                        //        DataTemplate template = presenter.ContentTemplate;
                        //        listBoxItem.Visibility = Visibility.Visible;
                        //    }
                        //}
                        //else
                        //{
                        foreach (var item in dataFood.Items)
                        {

                            ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                            ContentPresenter presenter = FindVisualChild<ContentPresenter>(listBoxItem);
                            DataTemplate template = presenter.ContentTemplate;
                            // Sta textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                            TextBlock textfoodid = template.FindName("textfoodid", presenter) as TextBlock;
                            listBoxItem.Visibility = Visibility.Visible;
                            bool hasFood = ListFood.Any(cus => cus.FId == Convert.ToInt32(textfoodid.Text));
                            if (hasFood == false)
                            {
                                listBoxItem.Visibility = Visibility.Collapsed;
                            }
                        }
                        //}
                        //dataFood.Focus();

                    }
                    else
                    {
                        dataFood.ItemsSource = ListFood;
                        //dataFood.Focus();
                    }
                }
                else
                {
                    foreach (var item in dataFood.Items)
                    {
                        ListBoxItem listBoxItem = this.dataFood.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                        listBoxItem.Visibility = Visibility.Collapsed;

                    }
                    MessageBox.Show("No Data Found!");

                }

            }

            else
            {
                BindFoods(Convert.ToInt32(cmbocategory.SelectedValue));
            }
        }

        private void ScrollViewer_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            ScrollViewer scv = (ScrollViewer)sender;
            scv.ScrollToVerticalOffset(scv.VerticalOffset - e.Delta);
            e.Handled = true;
        }

        private void ScrollViewer_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            try
            {

                if (e.NewSize.Width > 865)
                {
                    uniformgridButtons.Columns = 5;
                }
                else if (e.NewSize.Width > 699 && e.NewSize.Width < 865)
                {
                    uniformgridButtons.Columns = 4;
                }
                else
                {
                    uniformgridButtons.Columns = 3;
                }
            }
            catch { }
        }

        private void winDash_Loaded(object sender, RoutedEventArgs e)
        {
            this.MinWidth = 518;
        }
    }
}
